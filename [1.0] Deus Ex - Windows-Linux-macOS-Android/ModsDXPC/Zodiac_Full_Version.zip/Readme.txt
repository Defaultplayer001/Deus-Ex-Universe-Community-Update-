Deus Ex: ZODIAC (October 8, 2004)
---------------

ZODIAC is a single player add-on to the game Deus Ex consisting of a set of six linked missions.

Requirements:
-------------

1. Deus Ex must be installed on your computer.

2. Deus Ex version 1.109 or later is required.  Any multiplayer patch later than March 2, 2001 should work.  You can find the version 1.112fm patch here:
http://www.edgefiles.com/files/15591.html

The 1.014f patch does NOT include enough for ZODIAC to work properly.

3. The ZODIAC installation program is a Windows application, so it will only work on a PC.  A manual "Mac-friendly" version will also be available.


Installation:
-------------

To install ZODIAC, double-click on ZodiacSetup_Full.exe or ZodiacPart3Setup_Upgrade.exe and follow the prompts.  An Uninstall option will appear under "Zodiac" in you Start Menu programs.

Once installed, to launch ZODIAC, double-click on the ZODIAC icon.  Do not attempt to run it any other way - it will not work properly.

Enjoy.

NOTE: ZodiacPart3Setup_Upgrade.exe assumes that you have Part 2 installed and working first.


Installation notes:
-------------------

* If you'd like to play Deus Ex and/or ZODIAC without the CD in the drive, you can do the following:

For Deus Ex itself, pull up the DeusEx.ini file that's in your \DeusEx\System folder and remove the drive letter after "CdPath=".  For ZODIAC, do the same thing, but in the Zodiac.ini file.

* To play the original game instead of ZODIAC, simply launch it with your normal Deus Ex icon.  None of the original game files are overwritten or altered during installation.


Gameplay notes:
---------------

* It is assumed that you have finished the original Deus Ex and are already familiar with the weapons and some of the characters and storyline.

* The story of ZODIAC branches directly off from the middle of the Deus Ex story.  In ZODIAC, you will start out in a familiar location.  But don't worry, you'll be seeing new locations soon enough.

* If you plan on playing the future ZODIAC missions, be sure to keep a saved game near the end of the first mission.  Currently when you complete the mission, the credits will roll, but in the future, it will link to the next mission.



The Story so far...
-------------------

If it's been a while since you played Deus Ex (it was released in the year 2000 after all), then you might want to read this section.  If you still remember the storyline and characters of Deus Ex fairly well, you can skip this.

ZODIAC branches off from the storyline of Deus Ex.  In Deus Ex, you played JC Denton, but in ZODIAC, you play his brother Paul Denton.  

At the start of ZODIAC, you (Paul) have narrowly avoided death at the hands of the United Nations Anti-Terrorist Coalition (UNATCO) after several agents and troops show up at your apartment in New York City.  With the help of JC, you manage to escape.  In Deus Ex, it was possible for Paul to be killed, but in ZODIAC, it is assumed that JC does save him.

An arms dealer named Smuggler then helps you get to Hong Kong; your brother JC has made an alliance with a scientist named Tracer Tong who lives there.  Tong was able to recently remove JC's "kill switch" in his underground laboratory.

Paul had been a double agent for both UNATCO and the National Secessionist Force (NSF).  UNATCO considers the NSF nothing more than a terrorist group, and in fact, they do resort to terrorism to further their cause.  Their main concern is the proliferation of a deadly plague called the Gray Death.  They believe that the cure, known as Ambrosia, is being purposely held back by secret organizations.  Paul's loyalties are with the NSF.

When you start the game, you will be playing Paul Denton and you will be at Tracer Tong's lab in Hong Kong; JC has already left on an important mission related to stopping the Gray Death.  Talk to Tracer and Alex about a little mission of your own.  Unfortunately, UNATCO has enabled your kill switch, so you'll have to find new augmentations to replace your existing ones, which have been permanently disabled.



For the latest on ZODIAC, including the latest version, visit www.planetdeusex.com/zodiac

For Deus EX SDK tutorials and utilities, visit Tack's Deus Ex Lab at www.planetdeusex.com/tack

Steve Tack
stack@planetdeusex.com