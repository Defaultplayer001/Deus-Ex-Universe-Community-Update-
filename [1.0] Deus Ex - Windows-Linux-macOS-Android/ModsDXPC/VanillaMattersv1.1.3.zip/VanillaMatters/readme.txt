[CAUTION]
EXISTING SAVES FROM V1.1.0 AND OLDER ARE NOT COMPATIBLE FROM V1.1.1 FORWARD.

[INSTALLATION]
1. Extract to your Deus Ex directory. Make sure the extracted folder, "VanillaMatters", is next to another folder called "System":
Deus Ex
- System
- Textures
...
- VanillaMatters
2. Use VanillaMatters.exe to play. If you're using a Steam version then it automatically launches through Steam for you.
- Compatible with any version of the game, with/without kentie's launcher, or any other custom launcher.

[CONTACT]
Discord: https://discord.gg/bsVCvnu

[TROUBLESHOOTING]
1. You want to migrate previous Vanilla Matters ini files.
- Find your current DeusEx.ini and User.ini, move them into VanillaMatters/System. Then open DeusEx.ini, look for "[Core.System"], you should now see a list of "Paths=".
- Add these at the top of the Paths= list:
Paths=..\VanillaMatters\System\*.u
Paths=..\VanillaMatters\Maps\*.dx
Paths=..\VanillaMatters\Textures\*.utx
Paths=..\VanillaMatters\Sounds\*.uax
Paths=..\VanillaMatters\Music\*.umx
- That part should look like this after:
[Core.System]
...
Paths=..\VanillaMatters\System\*.u
Paths=..\VanillaMatters\Maps\*.dx
Paths=..\VanillaMatters\Textures\*.utx
Paths=..\VanillaMatters\Sounds\*.uax
Paths=..\VanillaMatters\Music\*.umx
Paths=..\System\*.u
Paths=..\Maps\*.dx
Paths=..\Textures\*.utx
Paths=..\Sounds\*.uax
Paths=..\Music\*.umx
...
- Rename DeusEx.ini into VanillaMatters.ini, rename User.ini into VanillaMattersUser.ini, and you're done.

2. Your game or the launcher crashed, now the vanilla game has Vanilla Matters texts:
- Simply run the VanillaMatters.exe again, it should clean stuff up, then close it if you don't want to keep playing.
- If this doesn't work, go into the "System" folder in your Deus Ex directory, delete DeusEx.int there, find a file with the ".vnt" extension, remove the ".vnt", it should be a normal ".int" file now.
- Finally the mod is packaged with a backup DeusEx.int, in VanillaMatters/Backups.

3. You get "Failed to find Steam" whenever you try to launch the game:
- If you've installed Deus Ex into a seperate Steam library folder on another partition, or copied a Steam version to have seperate installations, then you would need to use a custom launcher to escape Steam's DRM wrapper.
- Vanilla Matters' launcher doesn't do this for you, so try kentie's Launcher or Han's.

4. You're using a GoG copy and it asks for a CD:
- Simply go to VanillaMatters.ini and find a line called "CdPath=".
- It should say "CdPath=..\GOTY_1", remove the GOTY_1 part to say "CdPath=..\".