# ue1launcher
Launcher for Unreal Engine 1 games
***
**Countless thanks to [Hanfling](https://github.com/hanfling)** for his insights regarding Unreal Engine 1, ancient C++ knowledge, and providing/fixing the launcher source that this project is based on.  
Credits to [kentie](https://github.com/mkentie)'s [DeusExe project](https://github.com/mkentie/DeusExe) for various useful code snippets.
