#pragma warning( disable : 4201 )
#pragma warning( disable : 4595 )
#define STRICT
#include <windows.h>
#include <commctrl.h>
#include <shlobj.h>
#include "Engine.h"
#include "UnRender.h"
#include "Window.h"
#include "resource.h"
