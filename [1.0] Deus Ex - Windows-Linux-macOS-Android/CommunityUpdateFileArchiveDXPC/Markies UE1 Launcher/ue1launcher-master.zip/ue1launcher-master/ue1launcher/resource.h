//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Resource.rc
//
#define IDB_Logo                        101
#define IDDIALOG_Splash                 119
#define IDDIALOG_PatchDelta             120
#define IDICON_Mainframe2               128
#define IDC_Edit                        1002
#define IDC_Reset                       1003
#define IDC_Copying                     1007
#define IDC_CopyProgress                1008
#define IDC_Logo                        1024

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
