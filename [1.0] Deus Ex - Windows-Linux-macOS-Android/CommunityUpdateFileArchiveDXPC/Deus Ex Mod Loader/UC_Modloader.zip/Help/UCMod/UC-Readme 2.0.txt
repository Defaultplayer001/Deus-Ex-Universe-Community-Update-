Universal-Constructor V 2.0 Readme File
11/24/00 Edward Gann
e-mail: egann@mindspring.com
ICQ: 93254615

******The Universal Constructor Mod*************

This version is exactly the same as previous versions except for two things.  First, I've set up the UC Mod to work with the Mod Loader.  In addition, I've programmed it to actually work with the existing game.  Basically, when you pick up a DX Item or Aug that has been replaced in the UC, the UC will detect it and make the replacement automatically.


********INSTALLATION***********

1. Install the Mod Loader.

2.  Extract the Zip file to the DeusEx/System folder.

3. Start DX and open the Mod Loader screen.  THe UC Mod should be on the list.

*********The Mods************

There are three main areas of Mod Changes.  
	Changes to Augs
	Changes to Charged Pickups
	The UC Store.  

*********The Augs***********

The Augs can all be found in the Class View under Augmentations. You can add the new Augs the same way you added the old augs, however the old augs will no longer work if they have been replaced in the UC.

Here is a list of the new Augs.

	UCAugAqualung
	UCAugBallistic
	UCAugDefense
	UCAugEMP
	UCAugHeartLung
	UCAugHealing
	UCAugEnviro
	UCAugLight
	UCAugMuscle
	UCAugPower
	UCAugShield
	UCAugSpeed


*****The Changes

UCAugBallistic, UCAugEMP, UCAugEnviro, and UCAugShield: All of these protect the player from a certain type of damage. The UC system has eliminated the Energy Drain from these Augs over time, now they drain Energy based on the amount of damage they absorb.

The amount of Energy Drain is determined by the amount of Damage absorbed by the Aug times the DrainRate value in the Aug.  The DrainRate values are all set to .1 right now, although this may change as the system is balanced.

This system allows the player to leave the Augs on all the time and not worry about draining energy until they are needed. However there is also a quirk to the system, since the Augs protect against more damage at higher levels, they also drain more energy at higher levels.


UCAugDefense: This Aug now drains Energy only when a projectile is intercepted.  The rate of energy drained is set by the DrainRate value.


UCAugHeartLung: The HeartLung Aug, aka Synthetic Heart, now only drains energy when it is actually boosting one or more other augs. This even works for the UC Aug system, for instance if you are using a UCAugBallistic, the HeartLung will only drain energy when it actually absorbs energy. The energy Drain amount is the same with the regular Aug.


UCAugHealing: The Healing Aug now only drains energy when it is actually healing. The energy Drain and Healing amount are the same.


UCAugLight: This no longer drains any energy.:)


UCAugMuscle: The Muscle aug now only drains energy if you are carrying something in your hands that is too heavy for you to normally lift. This is determined by the mass of the item. If it is over 50, which is hard-coded into DX, then the aug will drain energy, otherwise the aug will not.


UCAugPower: The Power Recirculator no longer drains energy and it is always on.  This also means that it will not normally be displayed on the Hud, but works as normal on the Aug Screen.  Otherwise it operates the same as before.


UCAugSpeed:  The Speed Aug only drains energy when the player is moving.


All other Augs are the same as in DX. This system can be fun, try spawning a few commandos and setting up the Ballistic, Defense and Healing Aug.  A good time can be had by all.:) 
(No weapons needed.)

	
Aug Coding Notes: I subclassed Augmentation Manager to handle the changes.  UCMe destroys the AugmentationSystem created in DeusExPlayer and replaces it with an 	AugmentationManager. This allows the UI to access the AugmentationSystem in DeusExPlayer while the Augs are controlled by UCAugmentationSystem in UCMe.

If you want to change the Augmentations that the player has access to, for instance have a mix of UC and regular Augs or new ones you create, I would suggest that you create a new Subclass of UCMe and the UCAugmentationManager and make it the way you want, this will ensure that new changes to the UC will not overwrite your changes.


********Charged Pickups*********** 

To use the Charged Pickups, look under Inventory, Pickup, DeusExPickup and there are two classes; UCArmor and UCChargedPickup.  All of these items can be found under those two classes.  There are no changes from the previous version of the UC Mod other than the Name Changes.


Armor, Rebreathers, Tech Goggles, etc were very under utilized in the game.  I've made efforts to change that.  One thing I've done is eliminated the Enviro Skill, although it's still in the game at this time, it doesn't do anything in the UC Mods.  I would be willing to take suggestions on what to replace it with.  (My thoughts are Climbing right now.)

Ballistic Armor is now UCArmor_Ballistic
The Hazmat Suit is now UCArmor_HazMat

Similar changes to the Augs, they don't deteriorate over time, only due to damage.  The Augs and the Armors are Stackable, the augs take the damage first and reduce it by a percentage based on their level, then the Armors take the remaining damage and reduce it by 35% for ballistic and 50% for Hazmat. (These are equivalent to a Level 2 Aug of the same type.)

The Thermo Armor is now UCCP_AdaptiveArmor
The Rebreather is now UCCP_Rebreather
The Tech Gggles are now UCCP_TechGoggles

All are rechargeable using Prod Charger Ammo.  They each hold 2000 units of energy and one Prod cell will recharge 100 points.  The Tech Goggles drain 1 point per tick, the Rebreather 2 points, and the Thermo Armor 4 points.  

To recharge them, put them in your hand and hit the Semi-colon (;).  

The Tech Goggles now work like a Level 2 Vision Aug instead of a level 1.  The Rebreather only drains when you are actually in the water.  

All of the Charged Pickups and Armor are all removable.


	****Future Upgrade Alert.  I'm going to design IR and UV Laser Alarms that cannot be 	seen with the Naked Eye.  Your Tech Goggles will become valuable.

	****Possible Future Upgrade Alert.  If you pick up an additional Charged Pickup, I'm 	thinking about having it recharge whatever is in Inventory.

Armor Coding Notes: I subclassed Charged Pickups into ArmorUC, then copied the Ballistic Armor and Hazmat into new Classes under ArmorUC. This probably wasn't necessary, but I think Armor may change a lot as new ideas come in so I wanted the flexibility.

Charged Pickup Coding Notes: I subclassed ChargedPickups into ChargedPickupsUC and then copied these classes into Subclasses of ChargedPickupUC.  (Just like armor.)  


********The Store*********

DeusExStoreUC has been changed to UCDeusExStore. The only changes to the store have been bug fixes and name changes.  There are no known problems with the Store Items.

Store Items can be found under Decoration, DeusExDecoration, UCDeesExStore in the class browser.

I have created a number of Decorations that look like different types of Ammo, Weapons, and other Pickups.  They are all under the DeusExUCStore which is a subclass of DeusExPickup. 

All of the Items names are preceded with the word Store, followed by the name of the Item, followed by the designation UC.

When you put one of these decorations on the Map, you will need to open the Properties and set the Price and Quantity under DeusExUCStore properties. Once set, the player can target the Store Decoration and it will display the Item being sold, the Price and the Quantity. (Probably should add available credits huh?)

When they frob on it, the Item will be added to their Inventory and the Credits will be removed provided they, have enough credits and enough room in their Inventory.  Once the quantity reaches 0, the Item will be destroyed.



*****Modders Info*****

Any Modder out there can use the UC-mod as they wish.  I would appreciate a mention of the fact in your game doc.  If you have any trouble implementing any of these modifications, let me know and I'll be glad to Help.

*******Credits**********

EdGann: Creator, Coder

DarkStalker: Coder

All of Team UC has participated in some shape or form, thanks guys.
