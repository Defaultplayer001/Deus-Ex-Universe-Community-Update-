These are the files that need to be translated in order to add a new setup language!

Changes made from official versions included with GOTY
-Changed Patch1readme description to just patch
