------------------------------------------------------------------------------------------------------
***BACK UP YOUR OLD ENGINE.DLL FILE BEFORE PUTTING THE NEW FILE IN YOUR DEUS EX\SYSTEM DIRECTORY!!!***
------------------------------------------------------------------------------------------------------

This file should fix problems with the demorec and demoplay commands.

Syntax:

>demorec filename
>stopdemo
>demoplay filename

Demos will be recorded until the current map or game exits, or the stopdemo command is issued.
Demos are stored in the Deus Ex\System directory.

------------------------------------------------------------------------------------------------------
***BACK UP YOUR OLD ENGINE.DLL FILE BEFORE PUTTING THE NEW FILE IN YOUR DEUS EX\SYSTEM DIRECTORY!!!***
------------------------------------------------------------------------------------------------------