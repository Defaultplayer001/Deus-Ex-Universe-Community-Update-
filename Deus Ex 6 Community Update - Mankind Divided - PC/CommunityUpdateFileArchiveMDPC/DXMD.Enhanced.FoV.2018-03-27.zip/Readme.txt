Enhanced FoV Options for Deus Ex: Mankind Divided & Deus Ex: Breach

Author: Sean Pesce

This mod allows the user to change the Field of View in DXMD and Deus Ex: Breach at the press of a button. Most notably, this mod supports higher/lower values than the games normally allow, and lets the user change the rendered FoV of the first-person hands separately, so weapon animations won't look strange on higher FoV settings.



Installation: Copy version.dll and DXMD_FOV.ini into the \retail\ directory (usually C:\Program Files (x86)\Steam\SteamApps\common\Deus Ex Mankind Divided\retail)



Default keybinds:

Increase FoV: +

Decrease FoV: -

Increase Hands FoV: *Unbound*

Decrease Hands FoV: *Unbound*

Restore Player Preferred FoV: Backspace

Restore Game default FoV: Delete




You can change the keybinds and default FoVs by going to "\Deus Ex Mankind Divided\retail\" and editing DXMD_FOV.ini







If you find any bugs, please contact me at:
https://www.reddit.com/u/SeanPesce

Or visit my website:
https://SeanPesce.github.io/
