Deus Ex

single player patch 1.014f

company: ION Storm (www.ionstorm.com) /
         Eidos Interactive (www.eidos.com)

homesite: unknown

Single-Player Fixes 
� Added OpenGL rendering support 
� Misc bugfixes 
� Misc performance improvements 

