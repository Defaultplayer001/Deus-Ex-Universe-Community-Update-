DXIW Demo Tweaker 1.1.2
-----------------------
Double click on the file DXIW_Demo_Tweaker.exe and click Optimal under both tabs.
When you're done click 'Speichern' which means Save, and the file will be saved.

NOTE: On the Default.ini tab, Optimal sets your monitor refresh rate to 85hz.
If you are not sure what your monitor can handle, do the following:

- Right-click on the desktop and select Properties. 
- Click the Settings tab. 
- Click the Advanced button. 
- Click the Monitor tab. 

Use the Screen Refresh rate in the ManualRefreshRateHz field on the Default.ini tab.

If you get a COMDLG32.OCX missing error while running the config tool, try this:

- Download comdlg32.ocx from http://www.a-fluffy.demon.co.uk/homeworld/hwse/comdlg32.ocx
  and copy it to the \Windows\System32 directory.
- Open the Run dialog box (Start, Run) and type in
  'Regsvr32 c:\windows\system32\comdlg32.ocx' to register it as a valid DLL.

If any other files are said to be missing after this, look them up on Google and register
it the same way you did with comdlg32.ocx