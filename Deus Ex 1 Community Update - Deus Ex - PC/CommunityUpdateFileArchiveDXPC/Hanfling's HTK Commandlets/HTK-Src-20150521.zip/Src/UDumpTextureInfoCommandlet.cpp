/*=============================================================================
	UDumpTextureInfoCommandlet.cpp.
	Dumps information about textures in package.
	Copyright 2015 Sebastian Kaufel. All Rights Reserved.

	 history:
		* Created by Sebastian Kaufel
=============================================================================*/

#include "HTK.h"

/*-----------------------------------------------------------------------------
	UDumpTextureInfoCommandlet.
-----------------------------------------------------------------------------*/

class UDumpTextureInfoCommandlet : public UCommandlet
{
	DECLARE_CLASS(UDumpTextureInfoCommandlet,UCommandlet,CLASS_Transient,HTK)

	UDumpTextureInfoCommandlet()
	{
		guard(UDumpTextureInfoCommandlet::StaticConstructor);
		unguard;
	}

	void StaticConstructor()
	{
		guard(UDumpTextureInfoCommandlet::StaticConstructor);

		LogToStdout    = 0;
		IsServer       = 0;
		IsClient       = 0;
		IsEditor       = 1;
		LazyLoad       = 0;
		ShowErrorCount = 0;
		ShowBanner     = 0;

		unguard;
	}

	// Entry point.
	INT Main( const TCHAR* Parms )
	{
		guard(UDumpTextureInfoCommandlet::Main);

		// Parse commandline.
		FString PkgName;
		if (!ParseToken(Parms,PkgName,0))
			appErrorf( TEXT("Package not specified.") );

		// Load package.
		UObject* Pkg = LoadPackage( NULL, *PkgName, LOAD_NoFail );
		//GWarn->Logf( TEXT("Dumping %s."), Pkg->GetFullName() );

		for ( TObjectIterator<UTexture> It; It; ++It )
		{
			if ( *It && It->IsIn(Pkg) )
			{
				GWarn->Logf( It->GetFullName() );
				GWarn->Logf( TEXT("  Format:              %s"), GetTextureFormatString(It->Format) );
				GWarn->Logf( TEXT("  Palette:             %s"), It->Palette ? It->Palette->GetFullName() : TEXT("None") );
				GWarn->Logf( TEXT("  UBits:               %i"), It->UBits );
				GWarn->Logf( TEXT("  VBits:               %i"), It->VBits );
				GWarn->Logf( TEXT("  USize:               %i"), It->USize );
				GWarn->Logf( TEXT("  VSize:               %i"), It->VSize );
				GWarn->Logf( TEXT("  UClamp:              %i"), It->UClamp );
				GWarn->Logf( TEXT("  VClamp:              %i"), It->VClamp );
				GWarn->Logf( TEXT("  MipZero:             %s"), *GetColorFString(It->MipZero) );
				GWarn->Logf( TEXT("  MaxColor:            %s"), *GetColorFString(It->MaxColor) );
				GWarn->Logf( TEXT("  BumpMap:             %s"), It->BumpMap       ? It->BumpMap->GetFullName()       : TEXT("None") );
				GWarn->Logf( TEXT("  DetailTexture:       %s"), It->DetailTexture ? It->DetailTexture->GetFullName() : TEXT("None") );
				GWarn->Logf( TEXT("  MacroTexture:        %s"), It->MacroTexture  ? It->MacroTexture->GetFullName()  : TEXT("None") );
				GWarn->Logf( TEXT("  Diffuse:             %f"), It->Diffuse );
				GWarn->Logf( TEXT("  Specular:            %f"), It->Specular );
				GWarn->Logf( TEXT("  Alpha:               %f"), It->Alpha );
				GWarn->Logf( TEXT("  Scale:               %f"), It->Scale );
				GWarn->Logf( TEXT("  Friction:            %f"), It->Friction );
				GWarn->Logf( TEXT("  MipMult:             %f"), It->MipMult );
#if ENGINE_VERSION!=227
				GWarn->Logf( TEXT("  FootstepSound:       %s"), It->FootstepSound ? It->FootstepSound->GetFullName() : TEXT("None") );
#else
				for ( INT i=0; i<6; i++ )
					GWarn->Logf( TEXT("  FootstepSound[%i]:    %s"), i, It->FootstepSound[i] ? It->FootstepSound[i]->GetFullName() : TEXT("None") );
#endif
				GWarn->Logf( TEXT("  HitSound:            %s"), It->HitSound      ? It->HitSound->GetFullName()      : TEXT("None") );
				GWarn->Logf( TEXT("  PolyFlags:           0x%08x"), It->PolyFlags ); // TODO: List the actually flags!
				GWarn->Logf( TEXT("  bHighColorQuality:   %i"), It->bHighColorQuality );
				GWarn->Logf( TEXT("  bHighTextureQuality: %i"), It->bHighTextureQuality );
				GWarn->Logf( TEXT("  bRealtime:           %i"), It->bRealtime );
				GWarn->Logf( TEXT("  bParametric:         %i"), It->bParametric );
				GWarn->Logf( TEXT("  bHasComp:            %i"), It->bHasComp );
				GWarn->Logf( TEXT("  LODSet:              %s"), GetLODSetString(It->LODSet) );
				GWarn->Logf( TEXT("  AnimNext:            %s"), It->AnimNext      ? It->AnimNext->GetFullName()      : TEXT("None") );
				GWarn->Logf( TEXT("  PrimeCount:          %i"), It->PrimeCount );
				GWarn->Logf( TEXT("  MinFrameRate:        %f"), It->MinFrameRate );
				GWarn->Logf( TEXT("  MaxFrameRate:        %f"), It->MaxFrameRate );
				GWarn->Logf( TEXT("  Mips.Num():          %i"), It->Mips.Num() );
				GWarn->Logf( TEXT("  CompMips.Num():      %i"), It->CompMips.Num() );
				GWarn->Logf( TEXT("  CompFormat:          %s"), GetTextureFormatString(It->CompFormat) );
				GWarn->Logf( TEXT("") );
			}
		}

		return 0;
		unguard;
	}
};
IMPLEMENT_CLASS(UDumpTextureInfoCommandlet);

/*----------------------------------------------------------------------------
	The End.
----------------------------------------------------------------------------*/
