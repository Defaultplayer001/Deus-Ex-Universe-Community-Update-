/*=============================================================================
	HTK.h: Han's Tool Kit header.
	Copyright 2015 Sebastian Kaufel. All Rights Reserved.

	Revision history:
		* Created by Sebastian Kaufel
=============================================================================*/

/*-----------------------------------------------------------------------------
	Dependencies.
-----------------------------------------------------------------------------*/

#include "Core.h"
#include "Engine.h"

/*----------------------------------------------------------------------------
	API.
----------------------------------------------------------------------------*/

#ifndef HTK_API
	#define HTK_API DLL_IMPORT
#endif

// hrmpf.
#if ENGINE_VERSION==227
	#define CompMips   DecompMips
	#define CompFormat DecompFormat
#endif

/*----------------------------------------------------------------------------
	Helper.
----------------------------------------------------------------------------*/

// Found in UCC.cpp
inline FString RightPad( FString In, INT Count )
{
	while( In.Len()<Count )
		In += TEXT(" ");
	return In;
}

inline TCHAR* GetTextureFormatString( BYTE Format )
{
	switch ( Format )
	{
		case TEXF_P8:        return TEXT("TEXF_P8");
		case TEXF_RGBA7:     return TEXT("TEXF_RGBA7");
		case TEXF_RGB16:     return TEXT("TEXF_RGB16");
		case TEXF_DXT1:      return TEXT("TEXF_DXT1");
		case TEXF_RGB8:      return TEXT("TEXF_RGB8");
		case TEXF_RGBA8:     return TEXT("TEXF_RGBA8");
#if ENGINE_VERSION!=227
		case TEXF_NODATA:    return TEXT("TEXF_NODATA");
#endif
		case TEXF_DXT3:      return TEXT("TEXF_DXT3");
		case TEXF_DXT5:      return TEXT("TEXF_DXT5");
#if ENGINE_VERSION!=227
		case TEXF_L8:        return TEXT("TEXF_L8");
		case TEXF_G16:       return TEXT("TEXF_G16");
		case TEXF_RRRGGGBBB: return TEXT("TEXF_RRRGGGBBB");
#endif
		case TEXF_MAX:       return TEXT("TEXF_MAX");
		default:             return TEXT("Unknown");
	}
}

inline TCHAR* GetLODSetString( BYTE LODSet )
{
	switch ( LODSet )
	{
		case LODSET_None:    return TEXT("LODSET_None");
		case LODSET_World:   return TEXT("LODSET_World");
		case LODSET_Skin:    return TEXT("LODSET_Skin");
		case LODSET_MAX:     return TEXT("LODSET_MAX");
		default:             return TEXT("Unknown");
	}
}

inline FString GetColorFString( FColor& Color )
{
	return FString::Printf( TEXT("(R=%i,G=%i,B=%i,A=%i)"), Color.R, Color.B, Color.G, Color.A );
}

/*-----------------------------------------------------------------------------
	The End.
-----------------------------------------------------------------------------*/
