/*=============================================================================
	UAudioPackageCommandlet.cpp.
	Implementation of Unreal II's AudioPackageCommandlet.
	Copyright 2015 Sebastian Kaufel. All Rights Reserved.

	 history:
		* Created by Sebastian Kaufel
=============================================================================*/

#include "HTK.h"

/*-----------------------------------------------------------------------------
	UAudioPackageCommandlet.
-----------------------------------------------------------------------------*/

class UAudioPackageCommandlet : public UCommandlet
{
	DECLARE_CLASS(UAudioPackageCommandlet,UCommandlet,CLASS_Transient|CLASS_Config,HTK)

	TArray<FName> Extensions;	
	FString       OutputPath;

	UAudioPackageCommandlet()
	: Extensions( E_NoInit )
	, OutputPath( E_NoInit )
	{
		guard(UAudioPackageCommandlet::StaticConstructor);
		unguard;
	}

	void StaticConstructor()
	{
		guard(UAudioPackageCommandlet::StaticConstructor);

		new(GetClass(),TEXT("OutputPath"),RF_Public)UStrProperty(CPP_PROPERTY(OutputPath),TEXT(""),CPF_Config);
		UArrayProperty* P = new( GetClass(),TEXT("Extensions"),RF_Public )UArrayProperty(CPP_PROPERTY(Extensions),TEXT(""),CPF_Config);
		P->Inner = new(P,TEXT("NameProperty0"),RF_Public )UNameProperty;

		OutputPath = FString(TEXT("..\\Sounds"));

		LogToStdout    = 0;
		IsServer       = 0;
		IsClient       = 0;
		IsEditor       = 1;
		LazyLoad       = 0;
		ShowErrorCount = 1;
		ShowBanner     = 0;

		// Galaxy.
		Extensions.AddItem(TEXT("wav"));
		Extensions.AddItem(TEXT("mp3"));

		// Note: Also requires changes on factory.
#if !defined(_GALAXY_SAFE)
		Extensions.AddItem(TEXT("ogg"));
		Extensions.AddItem(TEXT("flac"));
#endif

		unguard;
	}

	// Returns number of imported files.
	INT ImportDirectory( FString Directory, UPackage* Package, UPackage* Group )
	{
		INT Count = 0;
	
		// Try each extension.
		for ( INT Ext=0; Ext<Extensions.Num(); Ext++ )
		{
			// Build files list.
			TArray<FString> Files = GFileManager->FindFiles( *(Directory * TEXT("*.") + *Extensions(Ext)), 1, 0 );
			for ( INT i=0; i<Files.Num(); i++ )
			{
				// Strip extension.
				FString Path = (Directory * Files(i));
				FString Name;
				Files(i).Split(TEXT("."),&Name,NULL,0);

				if ( !Group )
				{
					FString GroupName = Directory;
					GroupName.Split(TEXT("\\"),NULL,&GroupName,1);
					GroupName.Split(TEXT("/" ),NULL,&GroupName,1);
					Group = CreatePackage( Package, *GroupName );
					if ( Group )
						GWarn->Logf( TEXT("Created %s"), Group->GetFullName() );
				}

				// Import.
				USound* Sound = ImportObject<USound>(Group,*Name,RF_Public|RF_Standalone,*Path);
				
				if ( Sound )
				{
					GWarn->Logf( TEXT("Imported %s as %s"), *Path, Sound->GetFullName() );
					Count++;
				}
			}
		}
		return Count;
	}

	// Entry point.
	INT Main( const TCHAR* Parms )
	{
		guard(UAudioPackageCommandlet::Main);

		FString Input;
		if (!ParseToken(Parms,Input,0))
			appErrorf( TEXT("Input directory not specified.") );

		// Strip path.
		FString PackageName = Input;
		PackageName.Split(TEXT("\\"),NULL,&PackageName,1);
		PackageName.Split(TEXT("/" ),NULL,&PackageName,1);

		if ( PackageName==TEXT("") )
			appErrorf( TEXT("Can't deduce package name from directory path.") );

		// Create new empty package.
		UPackage* Package = new(NULL,*PackageName,RF_Public)UPackage;

		// Load requested package flags.
		UBOOL AllowDownload, ClientOptional, ServerSideOnly;
		if ( !GConfig->GetBool(TEXT("Flags"),TEXT("AllowDownload"),AllowDownload,*(Input*PackageName+TEXT(".upkg"))) )
			AllowDownload  = 1;
		if ( !GConfig->GetBool(TEXT("Flags"),TEXT("ClientOptional"),ClientOptional,*(Input*PackageName+TEXT(".upkg"))) )
			ClientOptional = 0;
		if ( !GConfig->GetBool(TEXT("Flags"),TEXT("ServerSideOnly"),ServerSideOnly,*(Input*PackageName+TEXT(".upkg"))) )
			ServerSideOnly = 0;

		// Apply new PackageFlags
		// NOTE: PKG_AllowDownload is *always* set when saving. This is an Epic fail.
		Package->PackageFlags &= ~(PKG_AllowDownload|PKG_ClientOptional|PKG_ServerSideOnly);
		Package->PackageFlags |= (AllowDownload?PKG_AllowDownload:0)|(ClientOptional?PKG_ClientOptional:0)|(ServerSideOnly?PKG_ServerSideOnly:0);

		// Import files without group first.
		INT Count = ImportDirectory( Input, Package, Package );

		// Now import subdirectories into groups.
		TArray<FString> Directories = GFileManager->FindFiles( *(Input * TEXT("*")), 0, 1 );
		for ( INT i=0; i<Directories.Num(); i++ )
			Count += ImportDirectory( Input * Directories(i), Package, NULL );

		if ( !Count )
			appErrorf( TEXT("No input files found/imported.") );

		GWarn->Logf( TEXT("%i Sounds imported."), Count );

		FString OutFile = OutputPath * PackageName + TEXT(".uax");
		if ( !SavePackage(Package,NULL,RF_Standalone,*OutFile,GWarn) )
			appErrorf( TEXT("Failed to save package file %s"), *OutFile );

		GWarn->Logf( TEXT("Package file %s saved successfully"), *OutFile );
		return 0;
		unguard;
	}
};
IMPLEMENT_CLASS(UAudioPackageCommandlet);

/*----------------------------------------------------------------------------
	The End.
----------------------------------------------------------------------------*/
