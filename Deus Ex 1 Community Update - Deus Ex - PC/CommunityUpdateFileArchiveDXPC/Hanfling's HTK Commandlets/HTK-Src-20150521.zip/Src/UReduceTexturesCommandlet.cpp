/*=============================================================================
	UReduceTexturesCommandlet.cpp. Moves CompMips into Mips slot.
	Copyright 2015 Sebastian Kaufel. All Rights Reserved.

	 history:
		* Created by Sebastian Kaufel
=============================================================================*/

#include "HTK.h"

/*-----------------------------------------------------------------------------
	UReduceTexturesCommandlet.
-----------------------------------------------------------------------------*/

class UReduceTexturesCommandlet : public UCommandlet
{
	DECLARE_CLASS(UReduceTexturesCommandlet,UCommandlet,CLASS_Transient,HTK)

	UReduceTexturesCommandlet()
	{
		guard(UReduceTexturesCommandlet::StaticConstructor);
		unguard;
	}

	void StaticConstructor()
	{
		guard(UReduceTexturesCommandlet::StaticConstructor);

		LogToStdout    = 0;
		IsServer       = 0;
		IsClient       = 0;
		IsEditor       = 1;
		LazyLoad       = 0;
		ShowErrorCount = 0;
		ShowBanner     = 0;

		unguard;
	}

	// Entry point.
	INT Main( const TCHAR* Parms )
	{
		guard(UReduceTexturesCommandlet::Main);

		// Parse commandline.
		FString InPkgName;
		if (!ParseToken(Parms,InPkgName,0))
			appErrorf( TEXT("Input package not specified.") );
		FString OutPkgName;
		if (!ParseToken(Parms,OutPkgName,0))
			appErrorf( TEXT("Output package not specified.") );

		// Append .utx extension to output package if extension is omnited.
		if ( OutPkgName.InStr(TEXT("."))==-1 )
			OutPkgName += TEXT(".utx");
		else if ( OutPkgName.InStr(TEXT("."),1)==(OutPkgName.Len()-1) )
			OutPkgName += TEXT("utx");

		GWarn->Logf( *OutPkgName );

		// Load package.
		UObject* Pkg = LoadPackage( NULL, *InPkgName, LOAD_NoFail );
		GWarn->Logf( TEXT("Loaded %s."), Pkg->GetFullName() );

		// Get rid of those nasty lazy loaders attached to the mips.
		UObject::ResetLoaders( NULL, 0, 1 );

		INT Count = 0;
		for ( TObjectIterator<UTexture> It; It; ++It )
		{
			if ( *It && It->IsIn(Pkg) )
			{
				if ( It->bHasComp )
				{
					GWarn->Logf( TEXT("Reducing: %s"), It->GetFullName() );

					// Move.
					It->Mips     = It->CompMips;
					It->Format   = It->CompFormat;
					It->bHasComp = 0;

					Count++;
				}
				
				// Set CompFormat to something more sane.
#if ENGINE_VERSION!=227
				It->CompFormat = TEXF_NODATA;
#else
				It->CompFormat = TEXF_P8;
#endif
			}
		}

		GWarn->Logf( TEXT("Reduced %i Textures."), Count );

		if ( !SavePackage(Pkg,NULL,RF_Standalone,*OutPkgName,GWarn) )
			appErrorf( TEXT("Failed to save package file %s"), *OutPkgName );

		return 0;
		unguard;
	}
};
IMPLEMENT_CLASS(UReduceTexturesCommandlet);

/*----------------------------------------------------------------------------
	The End.
----------------------------------------------------------------------------*/
