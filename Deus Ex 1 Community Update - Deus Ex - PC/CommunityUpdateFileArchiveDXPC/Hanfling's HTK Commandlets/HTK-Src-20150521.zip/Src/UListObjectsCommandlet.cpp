/*=============================================================================
	UListObjectsCommandlet.cpp. Lists objects in Package file.
	Copyright 2015 Sebastian Kaufel. All Rights Reserved.

	 history:
		* Created by Sebastian Kaufel
		* Switches for Bjoern.
=============================================================================*/

#include "HTK.h"

/*-----------------------------------------------------------------------------
	UListObjectsCommandlet.

	Switches i need to add because Bjoern can't use grep nor sed.
	Code was sexy prior beeing half about special cases for switches.
		-cp		Prints pathname instead of name for Class
		-op		Prints pathname instead of name for Object
		-na		Do not align output
		-ni		Do not indent object hierarchy
		-nc		Do not display class.
		-co		Just display all Classes used intead of each individual Object
-----------------------------------------------------------------------------*/

// Compare for UObject.
inline INT Compare( const UObject* T1, const UObject* T2 )
{
	TArray<FName> TempOne, TempTwo, TreeOne, TreeTwo;

	check(T1);
	check(T2);

	const UObject* Temp;
	for ( Temp=T1; Temp; Temp=Temp->GetOuter() )
		TempOne.AddItem( Temp->GetFName() );
	for ( Temp=T2; Temp; Temp=Temp->GetOuter() )
		TempTwo.AddItem( Temp->GetFName() );
	INT i;
	for ( i=TempOne.Num()-1; i>=0; i-- )
		TreeOne.AddItem( TempOne(i) );
	for ( i=TempTwo.Num()-1; i>=0; i-- )
		TreeTwo.AddItem( TempTwo(i) );

	for ( i=0; i<Max(TreeOne.Num(),TreeTwo.Num()); i++ )
	{
		if ( i==TreeOne.Num() )
			return -1;
		else if ( i==TreeTwo.Num() )
			return 1;

		INT Res = appStricmp( *TreeOne(i), *TreeTwo(i) );
		if ( Res )
			return Res;
	}

	return 0;
}

inline FString DepthIndent( FString In, UObject* Obj )
{
	FString Tmp;
	for ( Obj=Obj->GetOuter(); Obj; Obj=Obj->GetOuter() )
		Tmp += TEXT("  ");
	return Tmp+In;
}

class UListObjectsCommandlet : public UCommandlet
{
	DECLARE_CLASS(UListObjectsCommandlet,UCommandlet,CLASS_Transient,HTK)

	UListObjectsCommandlet()
	{
		guard(UListObjectsCommandlet::StaticConstructor);
		unguard;
	}

	void StaticConstructor()
	{
		guard(UListObjectsCommandlet::StaticConstructor);

		LogToStdout    = 0;
		IsServer       = 0;
		IsClient       = 0;
		IsEditor       = 1;
		LazyLoad       = 0;
		ShowErrorCount = 0;
		ShowBanner     = 0;

		unguard;
	}

	// Entry point.
	INT Main( const TCHAR* Parms )
	{
		guard(UListObjectsCommandlet::Main);

		UBOOL ClassPath=0, ObjectPath=0, NoAlign=0, NoIndent=0, NoClass=0, ClassOnly=0;

		// Parse switches.
		FString NextToken;
		while ( ParseToken(Parms,NextToken,0) )
		{
			if ( NextToken==TEXT("") )
				break;
			else if ( **NextToken!='-' )
				break;
			else if ( NextToken==TEXT("-cp") ) ClassPath  = 1;
			else if ( NextToken==TEXT("-op") ) ObjectPath = 1;
			else if ( NextToken==TEXT("-na") ) NoAlign    = 1;
			else if ( NextToken==TEXT("-ni") ) NoIndent   = 1;
			else if ( NextToken==TEXT("-nc") ) NoClass    = 1;
			else if ( NextToken==TEXT("-co") ) ClassOnly  = 1;
			else 
				appErrorf( TEXT("Unknown switch: %s"), NextToken );

			NextToken = TEXT("");
		}

		if ( NoClass && ClassOnly )
		{
			debugf( TEXT("Idiot.") );
			return 0;
		}

		// Check for package.
		FString PkgName = NextToken;
		//if( !ParseToken(Parms,PkgName,0) )
		if ( PkgName==TEXT("") )
			appErrorf( TEXT("A package file must be specified.") );

		// Get optionmal baseclass.
		FString BaseClassStr;
		UClass* BaseClass = NULL;
		if( ParseToken(Parms,BaseClassStr,0) )
			BaseClass = FindObjectChecked<UClass>( ANY_PACKAGE, *BaseClassStr );
		// TODO: Maybe retry with EditPackages loaded.
		if ( !BaseClass )
			BaseClass = UObject::StaticClass();

		// Load Package.
		UObject* Pkg = LoadPackage( NULL, *PkgName, LOAD_NoFail );
		check(Pkg);

		// Search loaded Objects.
		TArray<UObject*> PkgObj;
		if ( BaseClass==UObject::StaticClass() )
		{
			// Add package itself.
			if ( !ClassOnly )
				PkgObj.AddUniqueItem( Pkg );

			for ( TObjectIterator<UObject> ObjIt; ObjIt; ++ObjIt )
				if ( *ObjIt && ObjIt->IsIn( Pkg ) )
					PkgObj.AddUniqueItem( ClassOnly ? ObjIt->GetClass() : *ObjIt );
		}
		else
		{
			for ( TObjectIterator<UObject> ObjIt; ObjIt; ++ObjIt )
			{
				if ( *ObjIt && ObjIt->IsIn( Pkg ) && ObjIt->IsA(BaseClass) )
				{
					if ( ClassOnly )
						PkgObj.AddUniqueItem( ObjIt->GetClass() );
					else if ( NoIndent )
						PkgObj.AddUniqueItem( *ObjIt );
					else
						for ( UObject* Obj=*ObjIt; Obj; Obj=Obj->GetOuter() )
							PkgObj.AddUniqueItem( Obj );
				}
			}
		}

		// Sort Objects.
		Sort( &PkgObj(0), PkgObj.Num() );

		// Figure out alignment width.
		INT Alignment = 0;
		if ( !NoAlign && !ClassOnly )
		{
			for ( INT i=0; i<PkgObj.Num(); i++ )
				Alignment = Max( Alignment, appStrlen(ClassPath ? PkgObj(i)->GetClass()->GetPathName() : PkgObj(i)->GetClass()->GetName()) );
			Alignment = Min( Alignment, 39 );
		}

		// Print.
		for ( INT i=0; i<PkgObj.Num(); i++ )
		{
			if ( NoClass )
			{
				FString ObjectName = ObjectPath ? PkgObj(i)->GetPathName()             : PkgObj(i)->GetName();

				GWarn->Logf( NoIndent ? *ObjectName : *DepthIndent(ObjectName,PkgObj(i)) );				
			}
			else if ( ClassOnly )
			{
				GWarn->Logf( ClassPath ? PkgObj(i)->GetPathName() : PkgObj(i)->GetName() );
			}
			else
			{
				FString ClassName  = ClassPath  ? PkgObj(i)->GetClass()->GetPathName() : PkgObj(i)->GetClass()->GetName();
				FString ObjectName = ObjectPath ? PkgObj(i)->GetPathName()             : PkgObj(i)->GetName();

				GWarn->Logf
				(
					TEXT("%s %s"),
					NoAlign  ? *ClassName  : *(RightPad(ClassName,Alignment)),
					NoIndent ? *ObjectName : *DepthIndent(ObjectName,PkgObj(i))
				);
			}
		}

		return 0;
		unguard;
	}
};
IMPLEMENT_CLASS(UListObjectsCommandlet);

/*----------------------------------------------------------------------------
	The End.
----------------------------------------------------------------------------*/
