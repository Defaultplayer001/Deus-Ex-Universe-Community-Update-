/*=============================================================================
	UMusicPackagesCommandlet.cpp.
	Batch converts a directory of source files to umx files.
	Copyright 2015 Sebastian Kaufel. All Rights Reserved.

	 history:
		* Created by Sebastian Kaufel
=============================================================================*/

#include "HTK.h"

/*-----------------------------------------------------------------------------
	UMusicPackagesCommandlet.
-----------------------------------------------------------------------------*/

class UMusicPackagesCommandlet : public UCommandlet
{
	DECLARE_CLASS(UMusicPackagesCommandlet,UCommandlet,CLASS_Transient|CLASS_Config,HTK)

	TArray<FName> Extensions;	
	FString       OutputPath;

	UMusicPackagesCommandlet()
	: Extensions( E_NoInit )
	, OutputPath( E_NoInit )
	{
		guard(UMusicPackagesCommandlet::StaticConstructor);
		unguard;
	}

	void StaticConstructor()
	{
		guard(UMusicPackagesCommandlet::StaticConstructor);

		new(GetClass(),TEXT("OutputPath"),RF_Public)UStrProperty(CPP_PROPERTY(OutputPath),TEXT(""),CPF_Config);
		UArrayProperty* P = new( GetClass(),TEXT("Extensions"),RF_Public )UArrayProperty(CPP_PROPERTY(Extensions),TEXT(""),CPF_Config);
		P->Inner = new(P,TEXT("NameProperty0"),RF_Public )UNameProperty;

		OutputPath = FString(TEXT("..\\Music"));

		LogToStdout    = 0;
		IsServer       = 0;
		IsClient       = 0;
		IsEditor       = 1;
		LazyLoad       = 0;
		ShowErrorCount = 1;
		ShowBanner     = 0;

		// Galaxy.
		Extensions.AddItem(TEXT("mod"));
		Extensions.AddItem(TEXT("s3m"));
		Extensions.AddItem(TEXT("stm"));
		Extensions.AddItem(TEXT("it"));
		Extensions.AddItem(TEXT("xm"));
		Extensions.AddItem(TEXT("far"));
		Extensions.AddItem(TEXT("669"));

#if !defined(_GALAXY_SAFE)
		Extensions.AddItem(TEXT("ogg"));
		Extensions.AddItem(TEXT("flac"));
#endif

		unguard;
	}

	// Entry point.
	INT Main( const TCHAR* Parms )
	{
		guard(UMusicPackagesCommandlet::Main);

		FString Input;
		if (!ParseToken(Parms,Input,0))
			appErrorf( TEXT("Input directory not specified.") );

		// Stats.
		INT Count = 0;
	
		// Try each extension.
		for ( INT Ext=0; Ext<Extensions.Num(); Ext++ )
		{
			// Build files list.
			TArray<FString> Files = GFileManager->FindFiles( *(Input * TEXT("*.") + *Extensions(Ext)), 1, 0 );
			for ( INT i=0; i<Files.Num(); i++ )
			{
				// Strip extension.
				FString Path = (Input * Files(i));
				FString Name;
				Files(i).Split(TEXT("."),&Name,NULL,0);

				// Create new empty package.
				UPackage* Package = new(NULL,*Name,RF_Public)UPackage;

				// Import.
				UMusic* Music = ImportObject<UMusic>(Package,*Name,RF_Public|RF_Standalone,*Path);
				if ( !Music )
					appErrorf( TEXT("Failed to import %s"), *Path );

				// Save.
				FString OutFile = OutputPath * Name + TEXT(".umx");
				if ( !SavePackage(Package,NULL,RF_Standalone,*OutFile,GWarn) )
					appErrorf( TEXT("Failed to save package file %s"), *OutFile );

				// Notify of success.
				GWarn->Logf( TEXT("Package file %s saved successfully."), *OutFile );
				Count++;
			}
		}

		// Yell if we got no food.
		if ( !Count )
			appErrorf( TEXT("No input files found/imported.") );

		// Final stats.
		GWarn->Logf( TEXT("%i music packages created."), Count );
		return 0;
		unguard;
	}
};
IMPLEMENT_CLASS(UMusicPackagesCommandlet);

/*----------------------------------------------------------------------------
	The End.
----------------------------------------------------------------------------*/
