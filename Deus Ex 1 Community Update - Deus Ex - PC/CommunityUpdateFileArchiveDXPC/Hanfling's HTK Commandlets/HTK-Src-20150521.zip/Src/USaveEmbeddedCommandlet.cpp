/*=============================================================================
	USaveEmbeddedCommandlet.cpp.
	Saves an embedded package to a standalone package.
	Copyright 2015 Sebastian Kaufel. All Rights Reserved.

	 history:
		* Created by Sebastian Kaufel
=============================================================================*/

#include "HTK.h"

/*-----------------------------------------------------------------------------
	USaveEmbeddedCommandlet.
-----------------------------------------------------------------------------*/

class USaveEmbeddedCommandlet : public UCommandlet
{
	DECLARE_CLASS(USaveEmbeddedCommandlet,UCommandlet,CLASS_Transient,HTK)

	USaveEmbeddedCommandlet()
	{
		guard(USaveEmbeddedCommandlet::StaticConstructor);
		unguard;
	}

	void StaticConstructor()
	{
		guard(USaveEmbeddedCommandlet::StaticConstructor);

		LogToStdout    = 0;
		IsServer       = 0;
		IsClient       = 0;
		IsEditor       = 1;
		LazyLoad       = 0;
		ShowErrorCount = 0;
		ShowBanner     = 0;

		unguard;
	}

	// Entry point.
	INT Main( const TCHAR* Parms )
	{
		guard(USaveEmbeddedCommandlet::Main);

		// Parse commandline.
		FString InPkgName;
		if (!ParseToken(Parms,InPkgName,0))
			appErrorf( TEXT("Input package not specified.") );
		FString EmbeddedName;
		if (!ParseToken(Parms,EmbeddedName,0))
			appErrorf( TEXT("Embedded package not specified.") );
		FString OutPkgName;
		if (!ParseToken(Parms,OutPkgName,0))
			appErrorf( TEXT("Output package not specified.") );

		// Load package.
		UPackage* Pkg = CastChecked<UPackage>( LoadPackage( NULL, *InPkgName, LOAD_NoFail ) );

		// Search for inner package.
		UPackage* EmbPkg = NULL;
		TObjectIterator<UPackage> PkgIt;
		for ( PkgIt; PkgIt; ++PkgIt )
			if ( *PkgIt && PkgIt->IsIn( Pkg ) )
				if ( EmbeddedName==PkgIt->GetName() )
					break;

		EmbPkg = (UPackage*)*PkgIt;
		if ( !EmbPkg )
			appErrorf( TEXT("Failed to find embedded package %s"), *EmbeddedName );
		GWarn->Logf( TEXT("Found: %s"), EmbPkg->GetFullName() );

		if ( !SavePackage(EmbPkg,NULL,RF_Standalone,*OutPkgName,GWarn) )
			appErrorf( TEXT("Failed to save package file %s"), *OutPkgName );

		GWarn->Logf( TEXT("Package file %s saved successfully"), *OutPkgName );
		return 0;
		unguard;
	}
};
IMPLEMENT_CLASS(USaveEmbeddedCommandlet);

/*----------------------------------------------------------------------------
	The End.
----------------------------------------------------------------------------*/
