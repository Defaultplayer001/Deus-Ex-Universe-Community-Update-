========
Contents
========

This archive contains Nephthys.

Nephthys is a native modification for Unreal 1 engine based games (Unreal, Deus Ex, Rune).

It includes:
- enhanced security for servers
- web download for clients

============
Installation
============

Extract and run only Nephthys_v*_inst.exe and follow the instructions of the installer wizard.

You will be prompted for every installation option. The installer doesn't change your system as long as you don't click the "Install" button at the last screen.

Run the installer as the same Windows user as the game will run later.

====
Help
====

For more help see Help\Nephthys Documentation.html (after the installation is complete).

=========
Copyright
=========

(C) 2004-2008 Zora & Winged Unicorn

===========
End of File
===========